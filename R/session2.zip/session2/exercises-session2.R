

## Exercises for the Session2

## IVI
## -- 1. Calculate IVI for to top 20 species in Tropical Evergreen forest
## -- 2. Calculate IVI for the top 10 species in Kaeng Krung National Park (requires plot details in 'data' folder)

## Tree density per diameter class